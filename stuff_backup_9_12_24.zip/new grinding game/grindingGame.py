import pygame
import mapdata
from random import randint
from tkinter import ttk
import tkinter as tk
from os import getcwd

print("note: all enemies currently use a placeholder image")


enemy_timer = randint(1000, 2000)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
TILE_SIZE = 100  # Size of each block
PLAYER_SIZE = TILE_SIZE // 4  # Player is 1/4th the size of a tile
PLAYER_COLOR = GREEN
MOVE_SPEED = 3  # Movement speed in pixels

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500

# Initialize screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("game")

# Clock for controlling frame rate
clock = pygame.time.Clock()

# Player position
player_x = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2
player_y = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2
current_map = 1
current_chunk = 0

def loadchunk(map_id, chunk_id):
    global current_map, current_chunk, chunk_data
    current_map = map_id
    current_chunk = chunk_id
    chunk_data = mapdata.map1[int(chunk_id)]

    for row_index, row in enumerate(chunk_data):
        for col_index, block in enumerate(row):
            block_data = block.get()  # Get block attributes
            colour = block_data[0]   # Extract colour
            pygame.draw.rect(screen, colour,
                             (col_index * TILE_SIZE, row_index * TILE_SIZE, TILE_SIZE, TILE_SIZE))
            pygame.draw.rect(screen, BLACK,
                             (col_index * TILE_SIZE, row_index * TILE_SIZE, TILE_SIZE, TILE_SIZE), 1)

def can_move_to(new_x, new_y):
    tile_x = int(new_x // TILE_SIZE)
    tile_y = int(new_y // TILE_SIZE)

    # Ensure tile indices are in bounds
    if tile_x < 0 or tile_y < 0 or tile_x >= len(chunk_data[0]) or tile_y >= len(chunk_data):
        return False

    # Get the target block and check passability
    target_block = chunk_data[tile_y][tile_x]
    block_data = target_block.get()
    return block_data[1]  # Return the passable attribute

def handle_mapchanger(new_x, new_y):
    tile_x = int(new_x // TILE_SIZE)
    tile_y = int(new_y // TILE_SIZE)

    # Ensure tile indices are in bounds
    if tile_x < 0 or tile_y < 0 or tile_x >= len(chunk_data[0]) or tile_y >= len(chunk_data):
        return

    # Get the target block
    target_block = chunk_data[tile_y][tile_x]
    block_data = target_block.get()

    # Check if it's a mapchanger block
    if block_data[2][0] == "mapchanger":
        new_map, new_chunk = block_data[2][1]
        loadchunk(new_map, new_chunk)
        return True
    
playerstats = {"hp": 35, "xp": 0, "lv": 0, "maxhp": 35}
inventory = {"apple": 1, "medkit": 0}
















running = True
loadchunk(current_map, current_chunk)
last_enemy = 0

while running:
    if last_enemy == enemy_timer:
        spawn_enemy(playerstats, inventory)
        enemy_timer = randint(1500, 3000)
        last_enemy = 0
    else:
        last_enemy += 1

    screen.fill(WHITE)

    # Render the chunk
    loadchunk(current_map, current_chunk)

    # Draw the player
    pygame.draw.rect(screen, PLAYER_COLOR,
                     (player_x, player_y, PLAYER_SIZE, PLAYER_SIZE))

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Movement logic
    keys = pygame.key.get_pressed()
    new_x, new_y = player_x, player_y

    if keys[pygame.K_LEFT]:
        new_x -= MOVE_SPEED
    if keys[pygame.K_RIGHT]:
        new_x += MOVE_SPEED
    if keys[pygame.K_UP]:
        new_y -= MOVE_SPEED
    if keys[pygame.K_DOWN]:
        new_y += MOVE_SPEED

    # Check collision and update position
    if (can_move_to(new_x, player_y) and  # Horizontal collision check
        can_move_to(new_x + PLAYER_SIZE, player_y) and
        can_move_to(new_x, player_y + PLAYER_SIZE) and
        can_move_to(new_x + PLAYER_SIZE, player_y + PLAYER_SIZE)):
        player_x = new_x

    if (can_move_to(player_x, new_y) and  # Vertical collision check
        can_move_to(player_x + PLAYER_SIZE, new_y) and
        can_move_to(player_x, new_y + PLAYER_SIZE) and
        can_move_to(player_x + PLAYER_SIZE, new_y + PLAYER_SIZE)):
        player_y = new_y

    # Handle map changer blocks
    if handle_mapchanger(player_x, player_y) :
        player_x = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2
        player_y = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
