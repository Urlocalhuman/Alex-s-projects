from tkinter import ttk
import tkinter as tk
import socket
from threading import Thread
from time import sleep

timerfinished = 0
timer_running = 0

def timer(time):
    global timerfinished
    sleep(time)
    timerfinished = 1

def receive_messages(s, text):
    global timerfinished, timer_running
    while True:
        if timerfinished == 0 and timer_running == 0:
            myThread = Thread(target=timer, args=(1,))
            myThread.start()
            timer_running = 1
        if timerfinished == 1:
            timer_running = 0
            s.send("get".encode("utf-8"))
            newtext = s.recv(1024).decode("utf-8")
            text.delete("1.0", "end")
            text.insert("end", newtext)
            timerfinished = 0

def send_message(s, username, message):
    s.send(f"{username}: {message.get()}".encode("utf-8"))
    message.set("")  # Clear the message after sending

def main(old, servid, username):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("172.29.2.212", 44611))

    old.quit()
    root = tk.Tk()
    root.title(f"Discorb 2.0 chatting (server id {servid})")
    root.geometry("450x600")
    root.grid_columnconfigure(0, weight=1)
    root.grid_rowconfigure(0, weight=1)
    text = tk.Text(root, height=10)
    text.grid(row=0, column=0, sticky="nsew")
    scrollbar = ttk.Scrollbar(root, orient='vertical', command=text.yview)
    scrollbar.grid(row=0, column=1, sticky="ns")
    text['yscrollcommand'] = scrollbar.set
    text['state'] = 'disabled'
    message = tk.StringVar(value="")
    textbox = ttk.Entry(root, textvariable=message)
    textbox.grid(row=1, column=0, sticky="ew", padx=5, pady=5)
    textbox.focus()
    send = ttk.Button(root, text="Send", command=lambda: send_message(s, username, message))
    send.grid(row=1, column=1, sticky="ew", padx=5, pady=5)

    root.grid_rowconfigure(1, weight=0)
    root.grid_columnconfigure(1, weight=0)

    s.send(f"{servid}".encode("utf-8"))
    Thread(target=receive_messages, args=(s, text), daemon=True).start()

    root.mainloop()
    s.close()

def startbox():
    root = tk.Tk()
    root.title("Setup")
    root.geometry("450x450")
    root.resizable(False, False)

    ttk.Label(root, text='Choose a username and server id', font=("TkDefaultFont", 12)).pack()
    ttk.Label(root, text=' ', font=("TkDefaultFont", 12)).pack()
    ttk.Label(root, text='Username: ', font=("TkDefaultFont", 12)).pack()
    username = tk.StringVar()
    textbox = ttk.Entry(root, textvariable=username)
    textbox.pack()
    textbox.focus()

    ttk.Label(root, text=' ', font=("TkDefaultFont", 12)).pack()
    ttk.Label(root, text='Server ID:', font=("TkDefaultFont", 12)).pack()
    servid = tk.StringVar(value=0)
    spin_box = ttk.Spinbox(root, from_=0, to=5, textvariable=servid, wrap=True)
    spin_box.pack()
    button = ttk.Button(root, text='Continue', command=lambda: main(root, servid.get(), username.get())).pack()
    return root

root = startbox()
root.mainloop()
