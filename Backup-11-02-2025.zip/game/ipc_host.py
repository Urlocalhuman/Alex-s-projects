import socket
import threading
import pickle
playerstats = {}
enem_attk = "F"

HOST = 'localhost'
PORT = 44616

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(2)

def handle_client(client_socket, address):
    global playerstats, enem_attk
    print(f"Connection established with {address}")
    try:
        while True:
            message = client_socket.recv(1024).decode("utf-8")
            if message == "get":
                client_socket.send(pickle.dumps(playerstats))
                print(f"sent {playerstats} to {address}")

            if message == "send":
                playerstats = client_socket.recv(1024)
                playerstats = pickle.loads(playerstats)
                print(f"Got {playerstats} from {address}")

            if message == "eattk":
                enem_attk = client_socket.recv(1024).decode("utf-8")
                print(f"debug: eattk is now {enem_attk}")
                if enem_attk.lower() == "Tend":
                    enem_attk = "T"

            if message == "get_eattk":
                client_socket.send(enem_attk.encode("utf-8"))

            if message == "end":
                client_socket.close()
                break
                


    except ConnectionResetError:
        print(f"Connection with {address} lost.")
    finally:
        client_socket.close()
        print(f"Connection with {address} closed.")

try:
    while True:
        client_socket, address = server_socket.accept()
        client_thread = threading.Thread(target=handle_client, args=(client_socket, address))
        client_thread.start()
except KeyboardInterrupt:
    print("\nServer shutting down.")
finally:
    server_socket.close()
