import pygame
import mapdata
from random import randint
from tkinter import ttk
import tkinter as tk
from os import getcwd, system, startfile
import threading
from time import sleep
import socket
import pickle

startfile(f"{getcwd()}\\ipc_host.py")

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("localhost", 44616))

print("note: all enemies currently use a placeholder image")


enemy_timer = randint(1000, 2000)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
TILE_SIZE = 100  # Size of each block
PLAYER_SIZE = TILE_SIZE // 4  # Player is 1/4th the size of a tile
PLAYER_COLOR = GREEN
MOVE_SPEED = 3  # Movement speed in pixels

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 1000

# Initialize screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("game")

# Clock for controlling frame rate
clock = pygame.time.Clock()

# Player position
player_x = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2
player_y = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2
current_map = 1
current_chunk = 0

def loadchunk(map_id, chunk_id):
    global current_map, current_chunk, chunk_data
    current_map = map_id
    current_chunk = chunk_id
    chunk_data = mapdata.map1[int(chunk_id)]

    for row_index, row in enumerate(chunk_data):
        for col_index, block in enumerate(row):
            block_data = block.get()  # Get block attributes
            colour = block_data[0]   # Extract colour
            pygame.draw.rect(screen, colour,
                             (col_index * TILE_SIZE, row_index * TILE_SIZE, TILE_SIZE, TILE_SIZE))
            pygame.draw.rect(screen, BLACK,
                             (col_index * TILE_SIZE, row_index * TILE_SIZE, TILE_SIZE, TILE_SIZE), 1)

def can_move_to(new_x, new_y):
    tile_x = int(new_x // TILE_SIZE)
    tile_y = int(new_y // TILE_SIZE)


    if tile_x < 0 or tile_y < 0 or tile_x >= len(chunk_data[0]) or tile_y >= len(chunk_data):
        return False

    target_block = chunk_data[tile_y][tile_x]
    block_data = target_block.get()
    return block_data[1]

def handle_mapchanger(new_x, new_y):
    tile_x = int(new_x // TILE_SIZE)
    tile_y = int(new_y // TILE_SIZE)


    if tile_x < 0 or tile_y < 0 or tile_x >= len(chunk_data[0]) or tile_y >= len(chunk_data):
        return


    target_block = chunk_data[tile_y][tile_x]
    block_data = target_block.get()


    if block_data[2][0] == "mapchanger":
        new_map, new_chunk = block_data[2][1]
        loadchunk(new_map, new_chunk)
        return True
    
playerstats = {"hp": 35, "xp": 0, "lv": 0, "maxhp": 35, "gold": 100}
inventory = {"apple": 1, "medkit": 0, "weapon": 0}

# weapons:
# 0 - stick +0 atk

class Enemy:
    def __init__(self, playerstats, inventory, s):
        self.s = s
        self.playerstats = playerstats
        self.inventory = inventory
        self.enemstats = {"hp": randint(30, 50)}
        self.useditem = False
        self.inbattle = True

        self.root = tk.Tk()
        self.root.title("Enemy")
        self.root.geometry("300x200")
        
        self.ehplabel = ttk.Label(self.root, text=f"Enemy hp: {self.enemstats["hp"]}")
        self.ehplabel.place(x=200, y=10)
        self.hplabel = ttk.Label(self.root, text=f"Hp: {self.playerstats["hp"]}")
        self.hplabel.place(x=30, y=150)
        self.fightbutton = ttk.Button(self.root, text="Fight", command=self.fight)
        self.fightbutton.place(x=30, y=170)
        self.itembutton = ttk.Button(self.root, text="Items", command=self.items)
        self.itembutton.place(x=100, y=170)

        self.check = threading.Thread(target=self.checkhp, daemon=True)
        self.check.start()


    def items(self):
        self.itembox = tk.Tk()
        self.itembox.title("Items")
        self.itembox.geometry("200x150")
        self.medkitbutton = ttk.Button(self.itembox, text=f"Use medkit ({inventory["medkit"]} remaining)", command=self.usemedkit)
        self.applebutton = ttk.Button(self.itembox, text=f"Use apple ({inventory["apple"]} remaining)", command=self.useapple)
        self.applebutton.place(x=10, y=20)
        self.medkitbutton.place(x=10, y=60)

    def usemedkit(self):
        if not self.useditem and self.inventory["medkit"] > 0:
            self.playerstats["hp"] += 25
            self.useditem = True
            self.itembox.destroy()
            if self.playerstats["hp"] > self.playerstats["maxhp"]:
                self.playerstats["hp"] = self.playerstats["maxhp"]
            self.enemturn()

    def useapple(self):
        if not self.useditem and self.inventory["apple"] > 0:
            self.playerstats["hp"] += 10
            self.useditem = True
            self.itembox.destroy()
            if self.playerstats["hp"] > self.playerstats["maxhp"]:
                self.playerstats["hp"] = self.playerstats["maxhp"]
            self.enemturn()    

    def fight(self):
        damage = randint(5, 15)*(self.inventory["weapon"]+1) + (randint(1, 5)*self.playerstats["lv"])
        self.enemstats["hp"] -= damage
        self.ehplabel.config(text=f"Enemy hp: {self.enemstats["hp"]}")
        if self.checkhp():
            self.enemturn()

    def enemturn(self):
        self.s.send("send".encode("utf-8"))
        self.s.send(pickle.dumps(self.playerstats) )
        self.s.send("eattk".encode("utf-8"))
        self.s.send("T".encode("utf-8"))
        print("debug: send eattk")
        startfile(f"{getcwd()}\\enemattack.py")
        self.waiting = True
        while self.waiting:
            self.s.send("get_eattk".encode("utf-8"))
            if self.s.recv(1024).decode("utf-8") == "T":
                self.waiting = False
                print("finished waiting")
        sleep(1)
        self.s.send("get".encode("utf-8"))
        self.playerstats = self.s.recv(1024)
        self.playerstats = pickle.loads(self.playerstats)
        self.hplabel.config(text=f"Hp: {self.playerstats["hp"]}")
        self.useditem = False
        


    def checkhp(self):
        self.ehplabel.config(text=f"Enemy hp: {self.enemstats["hp"]}")
        self.hplabel.config(text=f"Hp: {self.playerstats["hp"]}")

        if self.enemstats["hp"] <= 0:
            self.playerstats["xp"] += randint(30, 50)
            self.playerstats["gold"] += randint(10, 40)
            self.end()

        if self.playerstats["hp"] <= 0:
            self.playerstats["hp"] = round(self.playerstats["maxhp"]/2)
            self.playerstats["gold"] -= 25
            self.end()
            return False
        else:
            return True

    def playerclose(self):
        if self.inbattle:
            self.end(1)

    def end(self, type=0):
        self.root.destroy()
        self.check.join()
        if type == 1:
            self.playerstats["gold"] -= 40            

    def run(self):
        self.root.protocol("WM_DELETE_WINDOW", self.playerclose)  
        self.root.mainloop()
        return self.playerstats, self.inventory

    


        










running = True
loadchunk(current_map, current_chunk)
last_enemy = 1000000

while running:
    if last_enemy >= enemy_timer:
        enemy = Enemy(playerstats, inventory, s)
        playerstats, inventory = enemy.run()
        enemy_timer = randint(1500, 3000)
        last_enemy = 0
    else:
        last_enemy += 1

    screen.fill(WHITE)

    loadchunk(current_map, current_chunk)

    pygame.draw.rect(screen, PLAYER_COLOR,
                     (player_x, player_y, PLAYER_SIZE, PLAYER_SIZE))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    new_x, new_y = player_x, player_y

    if keys[pygame.K_LEFT]:
        new_x -= MOVE_SPEED
    if keys[pygame.K_RIGHT]:
        new_x += MOVE_SPEED
    if keys[pygame.K_UP]:
        new_y -= MOVE_SPEED
    if keys[pygame.K_DOWN]:
        new_y += MOVE_SPEED

    if (can_move_to(new_x, player_y) and
        can_move_to(new_x + PLAYER_SIZE, player_y) and
        can_move_to(new_x, player_y + PLAYER_SIZE) and
        can_move_to(new_x + PLAYER_SIZE, player_y + PLAYER_SIZE)):
        player_x = new_x

    if (can_move_to(player_x, new_y) and
        can_move_to(player_x + PLAYER_SIZE, new_y) and
        can_move_to(player_x, new_y + PLAYER_SIZE) and
        can_move_to(player_x + PLAYER_SIZE, new_y + PLAYER_SIZE)):
        player_y = new_y

    if handle_mapchanger(player_x, player_y) :
        player_x = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2
        player_y = TILE_SIZE * 2 + TILE_SIZE // 2 - PLAYER_SIZE // 2

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
