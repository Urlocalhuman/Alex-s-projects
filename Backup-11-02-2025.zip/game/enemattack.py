import pygame
from random import randint
import math
import socket
import pickle
from time import sleep

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("localhost", 44616))
s.send("get".encode("utf-8"))
playerstats = s.recv(1024)
playerstats = pickle.loads(playerstats)

class enembullet:
    def __init__(self, player_x, player_y):
        self.existedtime = 0
        self.movetime = 0
        self.player_x = player_x
        self.player_y = player_y
        self.xpos = randint(1, 400)
        self.ypos = randint(1, 400)
        if self.ypos == self.player_y:
            self.xpos = randint(1, 400)
        if self.xpos == self.player_x:
            self.ypos = randint(1, 400)

    def tick(self):
        self.existedtime += 1
        if self.movetime >= 10:
            if self.player_x > self.xpos:
                self.xpos += 2
            if self.player_x < self.xpos:
                self.xpos -= 2
            if self.player_y > self.ypos:
                self.ypos += 2
            if self.player_y < self.ypos:
                self.ypos -= 2
            self.movetime = 0
        else:
            self.movetime += 1
        
        
        
        


def start(playerstats):
    pygame.init()
    spawntimer = 0
    timer = 0
    GREEN = (0, 255, 0)
    BLACK = (0, 0, 0)
    PLAYER_SIZE = 15
    PLAYER_COLOR = GREEN
    MOVE_SPEED = 1
    RED = (255, 0, 0)
    WHITE = (255, 255, 255)
    pygame.init()
    SCREEN_WIDTH = 500
    SCREEN_HEIGHT = 500
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("enemy attack")
    clock = pygame.time.Clock()
    player_x = 250
    player_y = 250
    enemies = []

    running = True
    while running:
        screen.fill(BLACK)
        pygame.draw.rect(screen, PLAYER_COLOR,
                        (player_x, player_y, PLAYER_SIZE, PLAYER_SIZE))
        font = pygame.font.Font(None, 36)
        text = font.render(f"HP: {playerstats["hp"]}", True, WHITE)
        screen.blit(text, (200, 30))
        spawntimer += 1
        timer += 1
        if spawntimer >= 400:
            enemies.append(enembullet(player_x, player_y))
            spawntimer = 0
        if timer >= 15000:
            running = False
            enemies.clear()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                playerstats["gold"] -= 50
                playerstats["hp"] -= 20
        keys = pygame.key.get_pressed()
        new_x, new_y = player_x, player_y

        if keys[pygame.K_LEFT]:
            player_x -= MOVE_SPEED
        if keys[pygame.K_RIGHT]:
            player_x += MOVE_SPEED
        if keys[pygame.K_UP]:
            player_y -= MOVE_SPEED
        if keys[pygame.K_DOWN]:
            player_y += MOVE_SPEED

        if player_x > SCREEN_WIDTH-30:
            player_x = SCREEN_WIDTH-30
        if  player_x < 0:
            player_x = 0
        if player_y > SCREEN_HEIGHT-30:
            player_y = SCREEN_HEIGHT-30
        if player_y < 0:
            player_y = 0

        for ebullet in enemies[:]:
            ebullet.player_x = player_x
            ebullet.player_y = player_y
            if ebullet.existedtime >= 800:
                enemies.remove(ebullet)
            else:
                ebullet.tick()
                pygame.draw.rect(screen, RED,
                                (ebullet.xpos, ebullet.ypos, 20, 20))
                distance = math.sqrt((ebullet.xpos - player_x) ** 2 + (ebullet.ypos - player_y) ** 2)
                if distance <= 5:
                    playerstats["hp"] -= 3
                    enemies.remove(ebullet)



        pygame.display.flip()

    
    pygame.quit()
    s.send("send".encode("utf-8"))
    s.send(pickle.dumps(playerstats))
    sleep(3)
    s.send("eattk".encode("utf-8"))
    s.send("T".encode("utf-8"))
    s.send("end".encode("utf-8"))
    
start(playerstats)