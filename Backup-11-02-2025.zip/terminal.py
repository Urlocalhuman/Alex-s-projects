from os import system
while True:
    system(input(">> "))