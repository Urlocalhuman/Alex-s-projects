cd \os
C:\qemu\qemu-system-i386.exe -kernel myos.bin