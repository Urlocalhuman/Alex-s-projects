cd \os
Remove-Item -Path "kernel.o", "boot.o", "myos.bin"
C:\gcc\bin\i686-elf-as boot.s -o boot.o
C:\gcc\bin\i686-elf-gcc -c kernel.c -o kernel.o -std=gnu99 -ffreestanding -O2 -Wall -Wextra
C:\gcc\bin\i686-elf-gcc  -T linker.ld -o myos.bin -ffreestanding -O2 -nostdlib boot.o kernel.o -lgcc
C:\qemu\qemu-system-i386.exe -kernel myos.bin