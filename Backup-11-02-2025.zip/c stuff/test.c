#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

void slashcheck(char *str) {
    int len = strlen(str);
    if (len == 0 || str[len - 1] != '\\') {
        str[len] = '\\';
        str[len + 1] = '\0';
    }
}


int main() {
    char input[200] = "";
    int looping = 1;
    char dir[200] = "C:\\";
    char newdir[200] = "";
    char delfile[200] = "";
    char confirm[3] = "";
    while(looping = 1) {
        printf("\n%s>> ", dir);
        fgets(input, 200, stdin);
        input[strcspn(input, "\n")] = '\0';
        if(strcmp(input, "?") == 0 || strcmp(input, "help") == 0) {
            printf("\nCommand (use 'list' for all cmds:): ");
            if (strcmp(input, "list") == 0) {
                printf("\nCommands list: ");
                printf("\nclear - clears the console");
                printf("\nend - closes the program");
                printf("\ndel - deletes a file");
                printf("\ncd - change directory");
                printf("\nAll inputs/commands need to be in lowercase except for file names and paths");
                printf("\n? or help - shows this\n");

            }

        }
        else if(strcmp(input, "end") == 0) {
            break;
        }
        else if(strcmp(input, "clear") == 0) {
            system("cls");
        }

        else if(strcmp(input, "cd") == 0) {
            printf("\nNew directory? ");
            fgets(newdir, 200, stdin);
            newdir[strcspn(newdir, "\n")] = '\0';
            if (access(newdir, F_OK) != -1) {
                slashcheck(newdir);
                strcpy(dir, newdir);
                }

            else {
                printf("\nDirectory '%s' does not exist", newdir);
            }
        }
        else{
            printf("Command does not exist: %s", input);
        }

    }
    printf("ending... ");
    return 0;
}
