import pygame

pygame.init()

# Screen dimensions
SCREEN_WIDTH = 900
SCREEN_HEIGHT = 700

# Colors
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARKGRAY = (100, 100, 100)
LIGHTBLUE = (0, 186, 255)
GBROWN = (77, 57, 23)
DGREEN = (0, 115, 6)
YELLOW = (255, 255, 0)
BROWN = (120, 72, 0)
PINK = (255, 0, 255)
PURPLE = (154, 0, 255)
ICE = (165, 255, 251)
VERYDARKGRAY = (64, 64, 64)
BURPLE = (82, 0, 163)

appopenid = 0
currentapp = None
app_open = False

def drawclosebutton(screen, coords):
    corner_x, corner_y = coords
    pygame.draw.rect(screen, RED, (corner_x, corner_y, 50, 50))
    xbutton = font.render("X", False, BLACK)
    screen.blit(xbutton, (corner_x + 17, corner_y + 15))   



# Initialize screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("gui thing")


# Clock for controlling frame rate
clock = pygame.time.Clock()
running = True
font = pygame.font.Font(None, 36)
while running:
    screen.fill(WHITE)

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_x:
                pass
    
    pygame.draw.rect(screen, DARKGRAY, (0, 670, 800, 25))

    if app_open:
        if appopenid == 1:
            pass
    
    pygame.display.flip()