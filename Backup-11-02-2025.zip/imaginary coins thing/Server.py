import threading
import socket
from base64 import b64encode, b64decode
import os
import pickle

HOST = '172.29.2.212'
PORT = 47699
MAX_CONNECTIONS = 10
lock = threading.Lock()

def readpass(user):
    with open(f"{user}pass.txt", "r") as file:
        password = b64decode(file.read().encode("utf-8"))
    return str(password)

def writepass(user, password):
    with open(f"{user}pass.txt", "w") as file:
        file.write(str(b64encode(password.encode("utf-8"))))


def useroperation(operation, username=None):
    if operation == "add":
        with open("users.txt", "r+") as file:
            userlist = file.readlines()
            userlist.append(username)
            fullstring = ""
            for line in userlist:
                fullstring = fullstring + f"
{line}"     
            file.truncate(0)
            file.write(fullstring)
        os.mkdir(f"{os.getcwd()}\\{username}")
        open(f"{username}pass.txt", "x").close()
        a = open(f"{os.getcwd()}\\{username}\\balance.txt", "x")
        a.write("0")
        a.close()

    if operation == "get":
        with open("users.txt", "r") as file:
            userlist = file.readlines
        return userlist


def createuser(username, password):
    open(f"{username}pass.txt", "x").close()
    writepass(username, password)
    useroperation("add", username)

def transaction(currentbalance, user, transaction_id):
    transactiondata = {"Name": "", "Cost": 0}
    with open(f"{os.getcwd()}\\{user}\\{transaction_id}.py", "r") as file:
        exec(f"transactiondata = {file.read()}")
    
    if currentbalance >= transactiondata["Cost"]:
        currentbalance -= transactiondata["Cost"]
        os.remove(f"{os.getcwd()}\\{user}\\{transaction_id}.py")
        with open(f"{os.getcwd()}\\{user}\\balance.txt", "r+") as file:
            userbalance = int(file.read())
            userbalance += transactiondata["Cost"]
            file.truncate(0)
            file.write(userbalance)

        return currentbalance
    
    else:
        return currentbalance

def getbalance(user):
    with open(f"{os.getcwd()}\\{user}\\balance.txt", "r") as file:
        a = file.read()
    return a

def getlistings(user):
    dirlist = os.listdir(f"{os.getcwd()}\\{user}")
    listingslist = []
    listingslist1 = []
    for dir in dirlist:
        if dir == "balance.txt":
            dirlist.remove(dir)
    
    for i in range(len(dirlist)):
        with open(f"{os.getcwd()}\\{user}\\{i-1}.py", "r") as file:
            exec(f"listingslist1.append({file.read()})")
            listingslist.append(f"Listing {i}: {listingslist1[i-1]["Name"]} for {listingslist1[i-1]["Cost"]} imaginary coins")

    return listingslist                

def addlisting(user, name, cost):
    dirlist = os.listdir(f"{os.getcwd()}\\{user}")
    for dir in dirlist:
        if dir == "balance.txt":
            dirlist.remove(dir)
    with open(f"{os.getcwd()}\\{user}\\{len(dirlist)+1}.py", "x") as file:
        file.write("\{\"Name\": \"" + name + "\", \"Cost\": " + str(cost) + "\}")

def clientthread(client_socket, address):
    print(f"Connection established with {address}")
    try:
        looping = True
        do = client_socket.recv(1024).decode("utf-8")
        username = client_socket.recv(1024).decode("utf-8")
        password = client_socket.recv(1024).decode("utf-8")
        if do == "createnew":
            createuser(username, password)
            writepass(username, password)
            client_socket.send("1".encode("utf-8"))
        elif do == "signin":
            if readpass() == password:
                client_socket.send("1".encode("utf-8"))
            else:
                client_socket.send("x".encode("utf-8"))
                looping = False
            
        while looping:
            message = client_socket.recv(1024).decode("utf-8")
            if message == "end":
                looping = False
            elif message == "buy":
                buyfrom = client_socket.recv(1024).decode("utf-8")
                buyid = client_socket.recv(1024).decode("utf-8")
                with open(f"{os.getcwd()}\\{username}\\balance.txt", "w") as file:
                    file.write(transaction(getbalance(username), buyfrom, buyid))
            elif message == "getbalance":
                client_socket.send(getbalance(username).encode("utf-8"))
            elif message == "getlistings":
                getfrom = client_socket.recv(1024).decode("utf-8")
                client_socket.send(pickle.dumps(getlistings(getfrom)))
            elif message == "addlisting":
                pass


    except ConnectionResetError:
        print(f"Connection with {address} lost.")
    finally:
        client_socket.close()
        print(f"Connection with {address} closed.")

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(MAX_CONNECTIONS)

print(f"Server started on {HOST}:{PORT}, waiting for connections...")

try:
    while True:
        client_socket, address = server_socket.accept()
        client_thread = threading.Thread(target=client_thread, args=(client_socket, address))
        client_thread.start()

except KeyboardInterrupt:
    print("\nServer shutting down.")
finally:
    server_socket.close()
        