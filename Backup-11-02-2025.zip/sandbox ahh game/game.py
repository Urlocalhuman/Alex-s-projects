import pygame
import block
from random import randint
from tkinter import ttk
import tkinter as tk
from os import getcwd, system, startfile
from time import sleep

pixel = block.Block

WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
BLACK = (0, 0, 0)
TILE_SIZE = 1  # Size of each block

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 500
SCREEN_HEIGHT = 500

# Initialize screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("game")

# Clock for controlling frame rate
clock = pygame.time.Clock()
data = []
temp = []
print("loading..")
for i in range(500):
    temp.append(pixel(WHITE, "blank", False))
for i in range(500):
    data.append(temp)    
data[0][40] = pixel(YELLOW, "test", True)
print(data[0][40].get())
running = True
paused = False

def draw(data):
    for c in range(500):
        for r in range(500):
            colour = data[c][r].get()
            colour = colour[0]
            pygame.draw.rect(screen, colour, (r*TILE_SIZE, c*TILE_SIZE, TILE_SIZE, TILE_SIZE))
    print("done draw")

def tick(data):
    for c in range(500):
        for r in range(500):
            data[c][r].ticked = False
    for c in range(500):
        for r in range(500):
            bdata = data[c][r].get()
            if data[c][r].ticked == False:
                #gravity
                if bdata[2]:
                    if (data[c-1][r].get())[1] == "blank":
                        data[c-1][r] = data[c][r]
                        data[c][r] = pixel(WHITE, "blank", False)
                        data[c-1][r].set(ticked=True)
                        
    print("done tick")
    return data




while running:

    draw(data)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_x]:
        pass

    if not paused:
        data = tick(data)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
