class Block:
    def __init__(self, colour, block_type, hasgravity):
        self.colour = colour
        self.block_type = block_type
        self.gravity = hasgravity
        self.ticked = False

    def get(self):
        return [self.colour, self.block_type, self.gravity, self.ticked]
    
    def set(self, colour=0, btype=0, hasgravity=0, ticked=0):
        if colour != 0:
            self.colour = colour
        if btype != 0:
            self.block_type = btype
        if hasgravity != 0:
            self.gravity = hasgravity
        if ticked != 0:
            self.ticked = ticked
        
    
        
