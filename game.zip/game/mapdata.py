from block import Block as b

WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
PURPLE = (160, 32, 240)
BROWN = (150, 75, 0)
YELLOW = (255, 255, 0)

class left(b):
    def __init__(self, map, chunk):
        if chunk == 0:
            to = 1
        elif chunk == 3:
            to = 5
        elif chunk == 4:
            to = 7
        elif chunk == 8:
            to = 4
        elif chunk == 2:
            to = 0
        elif chunk == 6:
            to = 3

        super().__init__(WHITE, True, ["mapchanger", [map, to]])

class up(b):
    def __init__(self, map, chunk):
        if chunk == 0:
            to = 3
        elif chunk == 1:
            to = 5
        elif chunk == 2:
            to = 6
        elif chunk == 8:
            to = 2
        elif chunk == 4:
            to = 0
        elif chunk == 7:
            to = 1
        super().__init__(WHITE, True, ["mapchanger", [map, to]])

class down(b):
    def __init__(self, map, chunk):
        if chunk == 0:
            to = 4
        elif chunk == 2:
            to = 8
        elif chunk == 1:
            to = 7
        elif chunk == 6:
            to = 2
        elif chunk == 3:
            to = 0
        elif chunk == 5:
            to = 1
        super().__init__(WHITE, True, ["mapchanger", [map, to]])

class right(b):
    def __init__(self, map, chunk):
        if chunk == 0:
            to = 2
        elif chunk == 3:
            to = 6
        elif chunk == 4:
            to = 8
        elif chunk == 7:
            to = 4
        elif chunk == 1:
            to = 0
        elif chunk == 5:
            to = 3

        super().__init__(WHITE, True, ["mapchanger", [map, to]])

class bblock(b):
    def __init__(self, colour):
        super().__init__(colour, False, ["normal"])

class blank(b):
    def __init__(self):
        super().__init__(WHITE, True, ["blank"])


# 10x10 chunks, 5x5 for testing
# chunk orientation:
# 5|3|6
# 1|0|2
# 7|4|8

map1 = [
    # base map with one chunk
    [
        [left(1, 0), up(1, 0), up(1, 0), up(1, 0), right(1, 0)],
        [left(1, 0), blank(), blank(), blank(), right(1, 0)],
        [left(1, 0), blank(), blank(), bblock(RED), right(1, 0)],
        [left(1, 0), blank(), blank(), blank(), right(1, 0)],
        [left(1, 0), down(1, 0), down(1, 0), down(1, 0), right(1, 0)]
    ],
    [
        [blank(), up(1, 1), up(1, 1), up(1, 1), right(1, 1)],
        [blank(), bblock(YELLOW), blank(), blank(), right(1, 1)],
        [blank(), bblock(YELLOW), blank(), blank(), right(1, 1)],
        [blank(), bblock(YELLOW), blank(), blank(), right(1, 1)],
        [blank(), down(1, 1), down(1, 1), down(1, 1), right(1, 1)]
    ],
    [
        [left(1, 2), up(1, 2), up(1, 2), up(1, 2), up(1, 2)],
        [left(1, 2), blank(), blank(), blank(), blank()],
        [left(1, 2), blank(), blank(), blank(), blank()],
        [left(1, 2), blank(), blank(), blank(), blank()],
        [left(1, 2), down(1, 2), down(1, 2), down(1, 2), blank()]
    ],
    [
        [left(1, 3), blank(), blank(), blank(), right(1, 3)],
        [left(1, 3), blank(), blank(), blank(), right(1, 3)],
        [left(1, 3), blank(), blank(), blank(), right(1, 3)],
        [left(1, 3), blank(), blank(), blank(), right(1, 3)],
        [left(1, 3), down(1, 3), down(1, 3), down(1, 3), right(1, 3)]        
    ],
    [
        [left(1, 4), up(1, 4), up(1, 4), up(1, 4), right(1, 4)],
        [left(1, 4), blank(), blank(), blank(), right(1, 4)],
        [left(1, 4), blank(), blank(), blank(), right(1, 4)],
        [left(1, 4), blank(), blank(), blank(), right(1, 4)],
        [left(1, 4), blank(), blank(), blank(), right(1, 4)]
    ],
    [
        [blank(), blank(), blank(), blank(), right(1, 5)],
        [blank(), blank(), blank(), blank(), right(1, 5)],
        [blank(), blank(), blank(), blank(), right(1, 5)],
        [blank(), blank(), blank(), blank(), right(1, 5)],
        [down(1, 5), down(1, 5), down(1, 5), down(1, 5), right(1, 5)]          
    ],
    [
        [left(1, 6), blank(), blank(), blank(), blank()],
        [left(1, 6), blank(), blank(), blank(), blank()],
        [left(1, 6), blank(), blank(), blank(), blank()],
        [left(1, 6), blank(), blank(), blank(), blank()],
        [left(1, 6), down(1, 6), down(1, 6), down(1, 6), down(1, 6)]        
    ],
    [
        [up(1, 7), up(1, 7), up(1, 7), up(1, 7), right(1, 7)],
        [blank(), blank(), blank(), blank(), right(1, 7)],
        [blank(), blank(), blank(), blank(), right(1, 7)],
        [blank(), blank(), blank(), blank(), right(1, 7)],
        [blank(), blank(), blank(), blank(), right(1, 7)]
    ],
    [
        [left(1, 8), up(1, 8), up(1, 8), up(1, 8), blank()],
        [left(1, 8), blank(), blank(), blank(), blank()],
        [left(1, 8), blank(), blank(), blank(), blank()],
        [left(1, 8), blank(), blank(), blank(), blank()],
        [left(1, 8), blank(), blank(), blank(), blank()]
    ]
]