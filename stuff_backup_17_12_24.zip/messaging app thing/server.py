import socket
import threading
from pathlib import Path
from os import getcwd

HOST = '172.29.2.212'
PORT = 44611
MAX_CONNECTIONS = 10
lock = threading.Lock()

def getservermsgs(server_id):
    path = Path(f"{getcwd()}\\{server_id}.s")
    if path.exists():
        with open(f"{server_id}.s", "r") as file:
            msgs = file.read()
    else:
        with open(f"{server_id}.s", "x") as file:
            msgs = f"SERVER: Created Server ID {server_id}"
            file.write(msgs)
    return msgs

def updateservermsgs(server_id, msgs):
    path = Path(f"{getcwd()}\\{server_id}.s")
    with lock:
        if path.exists():
            with open(f"{server_id}.s", "a") as file:
                file.write(f"\n{msgs}")
        else:
            with open(f"{server_id}.s", "x") as file:
                initial_msg = f"SERVER: Created Server ID {server_id}\n{msgs}"
                file.write(initial_msg)

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(MAX_CONNECTIONS)

print(f"Server started on {HOST}:{PORT}, waiting for connections...")

def handle_client(client_socket, address):
    print(f"Connection established with {address}")
    try:
        servid = client_socket.recv(1024).decode("utf-8")
        while True:
            message = client_socket.recv(1024).decode("utf-8")
            if message == "get":
                msgs = getservermsgs(servid)
                client_socket.send(msgs.encode("utf-8"))
            else:
                updateservermsgs(servid, message)

    except ConnectionResetError:
        print(f"Connection with {address} lost.")
    finally:
        client_socket.close()
        print(f"Connection with {address} closed.")

try:
    while True:
        client_socket, address = server_socket.accept()
        client_thread = threading.Thread(target=handle_client, args=(client_socket, address))
        client_thread.start()
except KeyboardInterrupt:
    print("\nServer shutting down.")
finally:
    server_socket.close()
