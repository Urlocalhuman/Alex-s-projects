import os
ver = 0.1
dir = "C:\\"

def join(list):
    string = "" 
    for i in range(len(list)):
        string = string + " " + list[i]
        string = string.strip()
        if string.endswith("\\"):
            string = string[:len(string)-2] 
    return string
    
        

while True:
    do = input(f"{dir} >> ")
    if not do:
        continue
    cmd = (do.strip()).split()
    length = len(cmd)

    if cmd[0] == "cd":
        if length > 1:
            if os.path.exists(join(cmd[1:])):
                dir = join(cmd[1:])
                continue 
            else:
                print("Path does not exist. ")
        else:
            print("No path given. ")

    elif cmd[0] == "dir":
        if length > 1:
            if os.path.exists(join(cmd[1:])):
                dirs = os.listdir(join(cmd[1:]))
                for i in range(len(dirs)):
                    print(dirs[i-1])
            else:
                print("Path does not exist. ")
        else:
            dirs = os.listdir(dir)
            for i in range(len(dirs)):
                print(dirs[i-1])

    elif cmd[0] == "del":
        if length > 1:
            if os.path.isfile(join(cmd[1:])):
                temp = input(f"Are you sure you want to delete {join(cmd[1:])}? (y/n)")
                if temp.lower() == "y":
                    os.remove(join(cmd[1:]))
            else:
                print(f"Path {join(cmd[1:])} does not exist. ")        