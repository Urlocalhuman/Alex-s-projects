class Block:
    def __init__(self, colour, passable, block_type):
        self.colour = colour
        self.passable = passable
        self.block_type = block_type

    def get(self):
        return [self.colour, self.passable, self.block_type]
